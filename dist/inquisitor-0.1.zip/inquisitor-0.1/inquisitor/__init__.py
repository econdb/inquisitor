# -*- coding: utf-8 -*-
"""
Created on Sun Feb 15 22:27:18 2015

@author: oriolandres
"""

from inquisitor import inquisitor

